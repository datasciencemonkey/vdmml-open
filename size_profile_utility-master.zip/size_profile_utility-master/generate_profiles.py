import pandas as pd
import numpy as np
from datetime import timedelta
from datetime import datetime
import swat
import re

###  These can be manipulated
df = dm_traindf.copy()
date_variable = 'FISCAL_START_DT'

profile_month_list = [1,3,12]
cls = "NON APPAREL FOOTWEAR WMNS SEAS"
#########
# Convert String DateVar to DateTime
df[date_variable] = pd.to_datetime(df[date_variable]) 
# Calculate Range in months for profile
total_months = round((max(df["FISCAL_START_DT"]) - min(df['FISCAL_START_DT']))/np.timedelta64(1, 'M'))

def get_profile_for_class(input_df=df, cls="NON APPAREL FOOTWEAR WMNS SEAS",size_col = 'size',
                          start_timestamp=min(df["FISCAL_START_DT"]),
                          end_timestamp=max(df["FISCAL_START_DT"])):
    """
    Takes an input dataframe, subsets for the start timestamp and the end timestamp. Creates a ByGroup on Size and
    then calulates the total sales units by size. Also calculates % of total units and removes sizes where 
    %total units is less than 1%
    
    Parameters:
    ----------
    cls: Optional; The product class interested in
    input_df: DataFrame; Required. Input dataframe to manipulate
    start_timestamp: Optional; The Starting timestamp 
    end_timestamp: Optional; The Ending timestamp 
    """
    sub_df= input_df[(input_df["FISCAL_START_DT"]>= start_timestamp) &( input_df["FISCAL_START_DT"] <=end_timestamp)]
    groupbySize = sub_df[sub_df['class']==cls].groupby(size_col)
    units_df=pd.DataFrame(groupbySize['SALES_UNITS'].sum())
    units_df['percent_units']=100*units_df['SALES_UNITS']/units_df['SALES_UNITS'].sum()
    units_df['product_class'] = cls
    units_df=units_df[units_df['percent_units']>1]
    return units_df

def create_rolling_profiles(profile_month_list,product_class,df):
    """
    Takes an input dataframe, a list of user speficifed month list for profile generation and 
    an user specified product class on the dataset to create rolling size profile data
    
    Parameters:
    ----------
    profile_month_list: User specified list
    product_class: User speficied class. Usually exposed via the cls variable
    df: Input data frame on which the compute needs to happen 
    """

    profile_df=pd.DataFrame()
    for profile_months in profile_month_list:

        parts = round(total_months/profile_months)
        print(f"INFO:There are a total of {parts} part(s) if profiled by a {profile_months} month window")
        size_of_part_in_days  = round(((max(df["FISCAL_START_DT"]) - min(df['FISCAL_START_DT'])).days)/parts)

        #generate time ranges for the profile generation
        date_ranges=[]
        for i in np.arange(round(parts)):
            cutover_date = min(df["FISCAL_START_DT"])+(timedelta(days=size_of_part_in_days)*(i+1))
            date_ranges.append(cutover_date)
        date_ranges.insert(0,min(df['FISCAL_START_DT']))
        date_ranges.insert(len(date_ranges),max(df['FISCAL_START_DT']))

        def _eliminate_final_cutdate(size_of_part_in_days):
            if (date_ranges[-1] - date_ranges[-2] < timedelta(days=size_of_part_in_days)):
                date_ranges.pop()
            else:
                pass

        _eliminate_final_cutdate(size_of_part_in_days)

        #subset dateranges and fetch profile
        for i  in range(len(date_ranges)):
            start_timestp = date_ranges[i]
            if i<len(date_ranges)-1:
                end_timestp = date_ranges[i+1] #get next timestamp and set as the end timestamp
                print(f"INFO: Now processing {profile_months} month profile between - {start_timestp,end_timestp}")
                result_profile_df=get_profile_for_class(start_timestamp= start_timestp,  end_timestamp=end_timestp,cls=product_class)
                result_profile_df['start_date'] = start_timestp
                result_profile_df['end_date'] = end_timestp
                result_profile_df['profile_months'] = profile_months
                profile_df = profile_df.append(result_profile_df)
            else:
                pass
    return profile_df

profile_df = create_rolling_profiles(profile_month_list,cls,df)
profile_df[profile_df.index.name]=profile_df.index
# profile_df.to_csv("profile_df.csv", index=True)
cashost='localhost'
casport=5570
casauth='~/.authinfo'
conn = swat.CAS(cashost, casport, authinfo=casauth)

try:
    cls_n = re.sub('[^0-9a-zA-Z]+', '', cls)
    table_name = datetime.now().strftime("%Y%m%d_%H%M")+'_'+cls_n.replace(' ','')+'_sizep'
    print("INFO: Writing to CASTable, Table will be promoted to global scope")
    out = conn.upload(profile_df, casout=dict(caslib='casuser',name=table_name,promote=True))
    print(f"INFO: The rolling  size profile data was written into {out['caslib']} caslib with the table name {out['tableName']}")
except:
    print("ERROR: CASTable wasn't created. Contact your admin/Check sys logs.")
