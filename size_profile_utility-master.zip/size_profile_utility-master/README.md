The `size profile utility` quickly computes size profiles across rolling time periods over an user specified profile length.

generate_profiles.py generates profiles across arbitrary user supplied `profile months` using the `profile_month_list` variable on the script. 
Currently the script doesnt gracefully handle passing params in the command line. A minor update will be done in the future to handle that.

This script is also used in `Model Studio`,where the results are pushed back to the user's caslib as a CASTable with a global scope
